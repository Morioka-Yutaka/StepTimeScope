filename P9F13558 list;

 %put NOTE- ;
 %put NOTE: Data for package StepTimeScope, version 0.1.0, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-11-02T18:28:10; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(StepTimeScope) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package StepTimeScope, version 0.1.0, license MIT;
%put NOTE- *** END ***;

/* lazydata.sas end */

